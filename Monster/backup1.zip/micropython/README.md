# Micropython for ESP8266 Quicknotes

## Erase & Flash the device

```
pip install esptool

// PRESS THE RESET BUTTON ...

esptool.py --chip esp8266 erase_flash

esptool.py --chip esp8266 write_flash --flash_mode dio --flash_size detect 0x0 esp8266-20220117-v1.18.bin
```
source: https://gndtovcc.home.blog/2020/04/16/flashing-micropython-firmware-with-esptool-py-on-esp32-and-esp8266/
